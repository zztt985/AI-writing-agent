from ai_writing_agent.config import load_config


def test_default_config():
    cfg = load_config(None)
    assert cfg.writing_type
    assert cfg.max_chunk_chars > 0
