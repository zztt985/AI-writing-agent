from pathlib import Path

from ai_writing_agent.document_loader import DocumentLoader


def test_load_and_chunk(tmp_path: Path):
    f = tmp_path / "a.txt"
    f.write_text("第一段\n\n第二段", encoding="utf-8")
    loader = DocumentLoader(max_chunk_chars=10)
    docs = loader.load_folder(tmp_path)
    chunks = loader.chunk_documents(docs)
    assert len(docs) == 1
    assert len(chunks) >= 1
    assert chunks[0].source_name == "a.txt"
