from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class SourceDocument:
    path: Path
    name: str
    suffix: str
    text: str


@dataclass
class SourceChunk:
    chunk_id: str
    source_name: str
    source_path: str
    index: int
    text: str
    char_count: int


@dataclass
class PipelineArtifacts:
    chunks: List[SourceChunk]
    key_info: str
    draft: str
    review: str
    final_text: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RunResult:
    markdown_path: Path
    json_path: Path
    final_path: Path
    review_path: Path
