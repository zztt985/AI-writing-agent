from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml
from dotenv import load_dotenv


@dataclass
class StyleConfig:
    tone: str = "稳重、真实、专业、自然"
    avoid_words: List[str] = field(default_factory=lambda: ["首先", "其次", "然后"])
    requirements: List[str] = field(default_factory=lambda: [
        "不编造材料中没有的数据",
        "明确核心痛点、核心逻辑和实际效果",
        "句子尽量有主语",
    ])


@dataclass
class ReviewConfig:
    enable_fact_risk_check: bool = True
    enable_logic_check: bool = True
    enable_style_check: bool = True


@dataclass
class AgentConfig:
    project_name: str = "科研项目成果总结"
    writing_type: str = "项目成果总结"
    language: str = "zh-CN"
    model: str = "gpt-4.1-mini"
    temperature: float = 0.25
    max_chunk_chars: int = 6000
    max_source_chunks: int = 20
    output_dir: str = "outputs"
    style: StyleConfig = field(default_factory=StyleConfig)
    review: ReviewConfig = field(default_factory=ReviewConfig)


def load_config(path: Optional[str] = None) -> AgentConfig:
    load_dotenv()
    cfg = AgentConfig()

    if path:
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        cfg.project_name = data.get("project_name", cfg.project_name)
        cfg.writing_type = data.get("writing_type", cfg.writing_type)
        cfg.language = data.get("language", cfg.language)
        cfg.model = data.get("model", cfg.model)
        cfg.temperature = float(data.get("temperature", cfg.temperature))
        cfg.max_chunk_chars = int(data.get("max_chunk_chars", cfg.max_chunk_chars))
        cfg.max_source_chunks = int(data.get("max_source_chunks", cfg.max_source_chunks))
        cfg.output_dir = data.get("output_dir", cfg.output_dir)

        style = data.get("style") or {}
        cfg.style = StyleConfig(
            tone=style.get("tone", cfg.style.tone),
            avoid_words=style.get("avoid_words", cfg.style.avoid_words),
            requirements=style.get("requirements", cfg.style.requirements),
        )

        review = data.get("review") or {}
        cfg.review = ReviewConfig(
            enable_fact_risk_check=bool(review.get("enable_fact_risk_check", cfg.review.enable_fact_risk_check)),
            enable_logic_check=bool(review.get("enable_logic_check", cfg.review.enable_logic_check)),
            enable_style_check=bool(review.get("enable_style_check", cfg.review.enable_style_check)),
        )

    env_model = os.getenv("OPENAI_MODEL")
    if env_model:
        cfg.model = env_model
    return cfg
