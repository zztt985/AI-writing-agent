from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from rich.console import Console

from .config import load_config
from .pipeline import WritingAgentPipeline
from .utils import ensure_dir

console = Console()


def cmd_run(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    if args.type:
        cfg.writing_type = args.type
    if args.model:
        cfg.model = args.model
    if args.output:
        cfg.output_dir = args.output

    pipeline = WritingAgentPipeline(cfg, mock=args.mock)
    result = pipeline.run(args.input, output_dir=cfg.output_dir)
    console.print("\n[bold]输出文件：[/bold]")
    console.print(f"- 完整报告：{result.markdown_path}")
    console.print(f"- 最终稿：{result.final_path}")
    console.print(f"- 评审意见：{result.review_path}")
    console.print(f"- 结构化数据：{result.json_path}")


def cmd_inspect(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    pipeline = WritingAgentPipeline(cfg, mock=True)
    pipeline.inspect(args.input)


def cmd_init(args: argparse.Namespace) -> None:
    target = ensure_dir(args.target)
    root = Path(__file__).resolve().parents[1]
    for name in ["config.example.yaml", ".env.example", "README.md", "requirements.txt"]:
        shutil.copy(root / name, target / name)
    examples_src = root / "examples"
    examples_dst = target / "examples"
    if examples_dst.exists():
        shutil.rmtree(examples_dst)
    shutil.copytree(examples_src, examples_dst)
    console.print(f"[green]已初始化到：{target}[/green]")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="AI 文稿工作流 Agent")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="运行完整写作流水线")
    run.add_argument("--input", required=True, help="材料文件或文件夹路径")
    run.add_argument("--config", default="config.example.yaml", help="配置文件路径")
    run.add_argument("--type", default=None, help="文稿类型，例如 项目成果总结、新闻稿、论文段落")
    run.add_argument("--output", default=None, help="输出目录")
    run.add_argument("--model", default=None, help="覆盖配置中的模型名称")
    run.add_argument("--mock", action="store_true", help="演示模式，不调用 OpenAI API")
    run.set_defaults(func=cmd_run)

    inspect = sub.add_parser("inspect", help="检查材料读取与分块情况")
    inspect.add_argument("--input", required=True, help="材料文件或文件夹路径")
    inspect.add_argument("--config", default="config.example.yaml", help="配置文件路径")
    inspect.set_defaults(func=cmd_inspect)

    init = sub.add_parser("init", help="初始化一个新项目目录")
    init.add_argument("--target", required=True, help="目标目录")
    init.set_defaults(func=cmd_init)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
