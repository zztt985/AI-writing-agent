from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

from .schemas import SourceChunk, SourceDocument
from .utils import normalize_text

SUPPORTED_SUFFIXES = {".txt", ".md", ".markdown", ".docx", ".pdf"}


class DocumentLoader:
    def __init__(self, max_chunk_chars: int = 6000):
        self.max_chunk_chars = max_chunk_chars

    def load_folder(self, folder_path: str | Path) -> List[SourceDocument]:
        folder = Path(folder_path)
        if not folder.exists():
            raise FileNotFoundError(f"资料路径不存在：{folder}")

        files: List[Path]
        if folder.is_file():
            files = [folder]
        else:
            files = [p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED_SUFFIXES]

        docs: List[SourceDocument] = []
        for file in sorted(files):
            text = self.load_file(file)
            if text.strip():
                docs.append(SourceDocument(path=file, name=file.name, suffix=file.suffix.lower(), text=text))
        if not docs:
            raise RuntimeError("未找到可读取材料。支持 .txt、.md、.docx、.pdf。")
        return docs

    def load_file(self, path: str | Path) -> str:
        p = Path(path)
        suffix = p.suffix.lower()
        if suffix in {".txt", ".md", ".markdown"}:
            return normalize_text(p.read_text(encoding="utf-8", errors="ignore"))
        if suffix == ".docx":
            return self._load_docx(p)
        if suffix == ".pdf":
            return self._load_pdf(p)
        raise ValueError(f"不支持的文件类型：{suffix}")

    def _load_docx(self, path: Path) -> str:
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("读取 docx 需要安装 python-docx。") from exc
        doc = Document(str(path))
        parts = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                if any(cells):
                    parts.append(" | ".join(cells))
        return normalize_text("\n".join(parts))

    def _load_pdf(self, path: Path) -> str:
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("读取 pdf 需要安装 pypdf。") from exc
        reader = PdfReader(str(path))
        pages = []
        for i, page in enumerate(reader.pages, start=1):
            pages.append(f"\n[PDF第{i}页]\n{page.extract_text() or ''}")
        return normalize_text("\n".join(pages))

    def chunk_documents(self, docs: Iterable[SourceDocument]) -> List[SourceChunk]:
        chunks: List[SourceChunk] = []
        for doc in docs:
            paragraphs = [x.strip() for x in doc.text.split("\n\n") if x.strip()]
            current: List[str] = []
            current_len = 0
            chunk_index = 1
            for para in paragraphs:
                if current and current_len + len(para) > self.max_chunk_chars:
                    text = "\n\n".join(current)
                    chunks.append(self._make_chunk(doc, chunk_index, text))
                    chunk_index += 1
                    current, current_len = [], 0
                if len(para) > self.max_chunk_chars:
                    for start in range(0, len(para), self.max_chunk_chars):
                        text = para[start:start + self.max_chunk_chars]
                        chunks.append(self._make_chunk(doc, chunk_index, text))
                        chunk_index += 1
                else:
                    current.append(para)
                    current_len += len(para)
            if current:
                chunks.append(self._make_chunk(doc, chunk_index, "\n\n".join(current)))
        return chunks

    def _make_chunk(self, doc: SourceDocument, index: int, text: str) -> SourceChunk:
        chunk_id = f"{doc.name}#chunk-{index}"
        return SourceChunk(
            chunk_id=chunk_id,
            source_name=doc.name,
            source_path=str(doc.path),
            index=index,
            text=normalize_text(text),
            char_count=len(text),
        )
