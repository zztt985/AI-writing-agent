from __future__ import annotations

from typing import List

from .config import AgentConfig
from .schemas import SourceChunk


def format_chunks(chunks: List[SourceChunk]) -> str:
    parts = []
    for c in chunks:
        parts.append(f"【来源：{c.chunk_id} | 文件：{c.source_name}】\n{c.text}")
    return "\n\n---\n\n".join(parts)


def extraction_prompts(cfg: AgentConfig, chunks: List[SourceChunk]) -> tuple[str, str]:
    system = f"""
你是一名严谨的科研与项目材料整理助手。你必须只根据用户给出的材料提取信息。
禁止编造数据、成果、单位、时间、人物、项目名称或结论。材料没有明确提到的内容，写“材料中未明确说明”。
输出语言：{cfg.language}。
""".strip()
    user = f"""
项目名称：{cfg.project_name}
文稿类型：{cfg.writing_type}

请从材料中提取结构化信息，输出以下部分：
一、项目或任务背景
二、要解决的核心痛点
三、已有工作基础
四、Agent 或 AI 工作流的核心逻辑
五、已取得的阶段性成果
六、可量化数据与证据
七、事实风险或待补充信息
八、后续可优化方向

每条信息后尽量标注来源片段，例如“来源：xxx#chunk-1”。

材料：
{format_chunks(chunks)}
""".strip()
    return system, user


def draft_prompts(cfg: AgentConfig, key_info: str) -> tuple[str, str]:
    avoid = "、".join(cfg.style.avoid_words)
    requirements = "\n".join(f"- {x}" for x in cfg.style.requirements)
    system = f"""
你是一名中文科研写作和项目申报材料写作助手。你的写作风格：{cfg.style.tone}。
必须真实、具体、克制，不夸大，不编造。避免使用这些机械连接词：{avoid}。
{requirements}
""".strip()
    user = f"""
请根据以下关键信息，生成一份“{cfg.writing_type}”初稿。

要求：
- 适合填写“使用 Agent 或 AI 驱动构建的具体成果”；
- 需要明确说明：核心痛点、核心逻辑、实际成果；
- 字数建议 700-1100 字；
- 没有数据支撑时，不要写百分比、绝对化结论或夸张措辞；
- 保留必要的来源提示或待补充标记。

关键信息：
{key_info}
""".strip()
    return system, user


def review_prompts(cfg: AgentConfig, draft: str, key_info: str) -> tuple[str, str]:
    system = """
你是一名严格的材料评审专家。你的任务是挑错，不是客气润色。
请重点检查事实风险、逻辑漏洞、表述空泛、数据缺失和成果夸大。
""".strip()
    user = f"""
请审查下面这份初稿，并结合关键信息判断是否可靠。

审查维度：
一、核心痛点是否清楚；
二、Agent 或 AI 工作流逻辑是否具体；
三、成果表述是否有材料依据；
四、是否存在夸大、空泛、不可验证的说法；
五、哪些地方需要补充数据或事实支撑；
六、给出逐条修改建议。

【关键信息】
{key_info}

【初稿】
{draft}
""".strip()
    return system, user


def polish_prompts(cfg: AgentConfig, draft: str, review: str) -> tuple[str, str]:
    system = """
你是一名专业中文文稿修改助手。请根据评审意见修改文稿。
要求：保留真实信息；删除或弱化缺乏依据的夸张表达；增强逻辑衔接；不编造新事实、新数据。
""".strip()
    user = f"""
请根据评审意见生成最终版本。

【初稿】
{draft}

【评审意见】
{review}

请只输出最终可填写版本，不要输出解释。
""".strip()
    return system, user
