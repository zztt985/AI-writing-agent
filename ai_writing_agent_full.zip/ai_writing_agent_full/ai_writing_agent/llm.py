from __future__ import annotations

import os
import time
from typing import List, Optional

class LLMClient:
    def __init__(self, model: str, temperature: float = 0.25, mock: bool = False):
        self.model = model
        self.temperature = temperature
        self.mock = mock
        self.client = None
        if not mock:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise RuntimeError("未检测到 OPENAI_API_KEY。请复制 .env.example 为 .env 并填写。也可以使用 --mock 先演示流程。")
            try:
                from openai import OpenAI
            except ImportError as exc:
                raise RuntimeError("未安装 openai 包。请先运行：pip install -r requirements.txt") from exc
            self.client = OpenAI(api_key=api_key)

    def generate(self, system_prompt: str, user_prompt: str, *, retries: int = 3) -> str:
        if self.mock:
            return self._mock_response(system_prompt, user_prompt)

        last_error: Optional[Exception] = None
        for attempt in range(retries):
            try:
                assert self.client is not None
                response = self.client.responses.create(
                    model=self.model,
                    input=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                    temperature=self.temperature,
                )
                return response.output_text.strip()
            except Exception as exc:
                last_error = exc
                time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"调用模型失败：{last_error}")

    def _mock_response(self, system_prompt: str, user_prompt: str) -> str:
        if "提取" in user_prompt or "关键信息" in user_prompt:
            return """一、项目或任务背景：围绕科研写作、项目总结和申报材料形成 AI 辅助流程。\n二、要解决的核心问题：材料分散、表述不统一、初稿生成效率低、逻辑检查依赖人工经验。\n三、已有工作基础：已有会议记录、项目计划、阶段成果、活动总结和论文摘要。\n四、技术路线或工作方法：读取资料、分块、归纳、提取关键信息、生成初稿、逻辑评审、最终修改。\n五、已取得的阶段性成果：已用于项目总结、实践活动新闻稿和论文段落修改。\n六、可量化数据：材料中未明确说明。\n七、存在的问题或不足：需要人工核查数字、事实、时间和项目名称。\n八、后续计划：继续补充材料库和审查规则。"""
        if "评审" in user_prompt or "检查" in user_prompt:
            return """1. 核心痛点较清楚，但可以更集中地说明人工流程中的时间成本和一致性问题。\n2. 工作流逻辑完整，需要补充每一步的输入输出。\n3. 成果表述总体稳妥，没有具体数据支撑时不应写百分比。\n4. 建议保留“已用于多个场景”，不要写“显著提升”等无法验证表达。\n5. 最终稿应明确人工复核仍是必要环节。"""
        return """我构建了一个面向科研写作和项目材料整理的 AI 工作流 Agent，用于解决资料分散、表述不统一、初稿生成效率低和逻辑检查依赖人工经验等问题。该 Agent 以本地材料为输入，先读取会议记录、项目计划、阶段成果、活动总结和论文摘要等文件，再将长文本切分为可处理的材料片段，并保留文件名和片段编号，便于后续追溯。\n\n在核心逻辑上，系统会先从材料中提取项目背景、核心问题、工作方法、阶段成果、可量化数据和待补充信息；随后根据文稿类型生成初稿，例如项目成果总结、新闻稿或论文段落；生成后，系统会继续进行事实风险、逻辑链条和表达风格检查，标记缺少依据、前后不一致或过于空泛的表述；最后，Agent 根据审查意见生成较稳妥的最终版本。\n\n目前，该工作流已经用于项目总结、实践活动新闻稿和论文段落修改等场景。它能够减少重复性的材料归纳和文字整理工作，使使用者把更多精力放在事实核对、观点深化和成果凝练上。对于材料中没有明确给出的数据，系统会提示“材料中未明确说明”，避免为了增强表达效果而虚构成果。整体来看，这一 Agent 提升了文档产出的规范性和一致性，也为后续项目申报、阶段总结和成果传播提供了可复用的写作流程。"""
