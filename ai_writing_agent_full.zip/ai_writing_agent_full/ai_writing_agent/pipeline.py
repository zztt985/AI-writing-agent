from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import List, Optional

from rich.console import Console

from .config import AgentConfig
from .document_loader import DocumentLoader
from .llm import LLMClient
from .prompts import draft_prompts, extraction_prompts, polish_prompts, review_prompts
from .schemas import PipelineArtifacts, RunResult, SourceChunk
from .utils import ensure_dir, estimate_tokens, now_stamp, safe_json_dump, slugify

console = Console()


class WritingAgentPipeline:
    def __init__(self, cfg: AgentConfig, *, mock: bool = False):
        self.cfg = cfg
        self.loader = DocumentLoader(max_chunk_chars=cfg.max_chunk_chars)
        self.llm = LLMClient(model=cfg.model, temperature=cfg.temperature, mock=mock)
        self.mock = mock

    def run(self, input_path: str | Path, output_dir: Optional[str | Path] = None) -> RunResult:
        out_dir = ensure_dir(output_dir or self.cfg.output_dir)
        run_name = f"{now_stamp()}_{slugify(self.cfg.writing_type)}"

        console.print("[bold]1/6 读取材料...[/bold]")
        docs = self.loader.load_folder(input_path)
        chunks = self.loader.chunk_documents(docs)
        selected_chunks = self._select_chunks(chunks)

        console.print(f"读取文件 {len(docs)} 个，材料片段 {len(chunks)} 个，进入模型片段 {len(selected_chunks)} 个。")

        console.print("[bold]2/6 提取关键信息...[/bold]")
        sys, usr = extraction_prompts(self.cfg, selected_chunks)
        key_info = self.llm.generate(sys, usr)

        console.print("[bold]3/6 生成初稿...[/bold]")
        sys, usr = draft_prompts(self.cfg, key_info)
        draft = self.llm.generate(sys, usr)

        console.print("[bold]4/6 评审检查...[/bold]")
        sys, usr = review_prompts(self.cfg, draft, key_info)
        review = self.llm.generate(sys, usr)

        console.print("[bold]5/6 生成最终稿...[/bold]")
        sys, usr = polish_prompts(self.cfg, draft, review)
        final_text = self.llm.generate(sys, usr)

        artifacts = PipelineArtifacts(
            chunks=selected_chunks,
            key_info=key_info,
            draft=draft,
            review=review,
            final_text=final_text,
            metadata={
                "project_name": self.cfg.project_name,
                "writing_type": self.cfg.writing_type,
                "model": self.cfg.model,
                "mock": self.mock,
                "source_documents": [str(d.path) for d in docs],
                "input_tokens_estimated": sum(estimate_tokens(c.text) for c in selected_chunks),
            },
        )

        console.print("[bold]6/6 写入输出文件...[/bold]")
        markdown_path = out_dir / f"{run_name}_report.md"
        json_path = out_dir / f"{run_name}_artifacts.json"
        final_path = out_dir / f"{run_name}_final.txt"
        review_path = out_dir / f"{run_name}_review.txt"

        markdown_path.write_text(self._render_markdown(artifacts), encoding="utf-8")
        final_path.write_text(final_text, encoding="utf-8")
        review_path.write_text(review, encoding="utf-8")
        safe_json_dump(artifacts, json_path)

        console.print(f"[green]完成。输出目录：{out_dir}[/green]")
        return RunResult(markdown_path=markdown_path, json_path=json_path, final_path=final_path, review_path=review_path)

    def inspect(self, input_path: str | Path) -> List[SourceChunk]:
        docs = self.loader.load_folder(input_path)
        chunks = self.loader.chunk_documents(docs)
        for doc in docs:
            console.print(f"[bold]{doc.name}[/bold]  字数：{len(doc.text)}")
        console.print(f"合计片段：{len(chunks)}")
        return chunks

    def _select_chunks(self, chunks: List[SourceChunk]) -> List[SourceChunk]:
        return chunks[: self.cfg.max_source_chunks]

    def _render_markdown(self, artifacts: PipelineArtifacts) -> str:
        source_list = "\n".join(f"- {c.chunk_id}：{c.source_path}（{c.char_count} 字符）" for c in artifacts.chunks)
        return f"""# AI 文稿工作流 Agent 输出报告

## 运行信息

- 项目名称：{artifacts.metadata.get('project_name')}
- 文稿类型：{artifacts.metadata.get('writing_type')}
- 使用模型：{artifacts.metadata.get('model')}
- 演示模式：{artifacts.metadata.get('mock')}
- 估算输入 Token：{artifacts.metadata.get('input_tokens_estimated')}

## 来源片段

{source_list}

---

## 一、提取的关键信息

{artifacts.key_info}

---

## 二、初稿

{artifacts.draft}

---

## 三、逻辑与事实风险检查

{artifacts.review}

---

## 四、最终可用版本

{artifacts.final_text}
"""
