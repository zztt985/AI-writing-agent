# AI 文稿工作流 Agent（完整版）

这是一个可直接运行的本地 Python 项目，用于把分散材料自动整理成项目成果总结、申报书段落、新闻稿、论文段落等文本。它不是单次问答脚本，而是一个完整流水线：

1. 读取 `.txt`、`.md`、`.docx`、`.pdf` 材料；
2. 自动分块并保留来源信息；
3. 提取结构化关键信息；
4. 生成初稿；
5. 做事实风险、逻辑链条、表达风格检查；
6. 按评审意见生成最终稿；
7. 输出 Markdown、JSON、审查报告和运行日志。

## 快速开始

```bash
cd ai_writing_agent_full
python -m venv .venv
source .venv/bin/activate  # Windows 用 .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

编辑 `.env`，填入 `OPENAI_API_KEY`。

运行示例：

```bash
python -m ai_writing_agent run --input examples/materials --config config.example.yaml
```

不调用 API 的演示模式：

```bash
python -m ai_writing_agent run --input examples/materials --config config.example.yaml --mock
```

输出文件会生成在 `outputs/` 目录。

## 常用命令

初始化配置和示例材料：

```bash
python -m ai_writing_agent init --target my_agent_project
```

检查材料能否读取：

```bash
python -m ai_writing_agent inspect --input examples/materials
```

运行并指定文稿类型：

```bash
python -m ai_writing_agent run --input examples/materials --type 项目成果总结 --output outputs
```

## 目录结构

```text
ai_writing_agent_full/
├── ai_writing_agent/
│   ├── __main__.py
│   ├── cli.py
│   ├── config.py
│   ├── document_loader.py
│   ├── llm.py
│   ├── pipeline.py
│   ├── prompts.py
│   ├── schemas.py
│   ├── utils.py
│   └── prompts/
├── examples/materials/
├── tests/
├── config.example.yaml
├── .env.example
├── requirements.txt
└── README.md
```

## 注意

- 程序不会替你编造数据。材料中没有的数据会被标记为“材料中未明确说明”。
- 生成内容仍需要人工最终核对，尤其是数字、单位、时间、姓名、项目名称和引用信息。
- PDF 扫描件如果没有文本层，普通 PDF 解析无法读取，需要先 OCR。
